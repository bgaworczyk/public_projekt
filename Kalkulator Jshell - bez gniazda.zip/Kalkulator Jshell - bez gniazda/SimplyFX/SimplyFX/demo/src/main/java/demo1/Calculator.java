package demo1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import jdk.jshell.JShell;
import jdk.jshell.SnippetEvent;

import java.io.IOException;
import java.util.List;

public class Calculator extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Calculator.class.getResource("calculator-view2.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 480);
        stage.setTitle("Computations here");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public static String compute(String request) {
        String output = null;
        JShell jshell = JShell.create();
        try (jshell) { // automatyczne zwalnianie zasobów we frazie try-catch, od JDK9
            List<SnippetEvent> events = jshell.eval(request);
            for (SnippetEvent e : events) {
                if (e.causeSnippet() == null) {
                    switch (e.status()) {
                        case VALID:
                            if (e.value() != null) {
                                System.out.printf("%s = %s\n", request, e.value());
                                output = (String) e.value();
                            }
                            break;
                        default: System.out.printf("Error\n"); output = "Error";
                            break;
                    }}}}
        return output;
    }

}
