import java.util.Scanner;
import java.util.*;
import java.io.*;

public class Battleship {
    public static void main(String[] args) {
        System.out.println("Welcome to Battleship!");
        char[][] target_arr1 = initArray(5, 5, '-'); // tracker strzałów 1go
        char[][] target_arr2 = initArray(5, 5, '-');
        char[][] LB1 = locationBoardsSetUp(1);
        char[][] LB2 = locationBoardsSetUp(2);
        boolean out1 = false;
        boolean out2 = false;
        boolean already1 = false;
        boolean already2 = false;
        do {
            do {
                Object[] hitArrays = hitArray(target_arr1, LB2, 1);
                target_arr1 = (char[][]) hitArrays[0];
                out1 = (boolean) hitArrays[2];
                already1 = (boolean) hitArrays[3];
            }
            while (out1 == true | already1 == true);
            printBattleShip(target_arr1);

            if (ships_sunk(target_arr1) == 5) break;

            do {
                Object[] hitArrays2 = hitArray(target_arr2, LB1, 2);
                target_arr2 = (char[][]) hitArrays2[0];
                out2 = (boolean) hitArrays2[2];
                already2 = (boolean) hitArrays2[3];
            }
            while (out2 == true | already2 == true);
            printBattleShip(target_arr2);
        }

        while (ships_sunk(target_arr2) < 5 & ships_sunk(target_arr1) < 5); //both below 5 to keep game running
        if (ships_sunk(target_arr2) == 5) System.out.println("PLAYER 2 WINS! YOU SUNK ALL OF YOUR OPPONENT’S SHIPS!");
        else System.out.println("PLAYER 1 WINS! YOU SUNK ALL OF YOUR OPPONENT’S SHIPS!");        ;

        System.out.println("\n"+"Final boards:"+"\n");
        printBattleShip(LB1);
        System.out.println("\n");
        printBattleShip(LB2);
    }


    // Use this method to print game boards to the console.
    private static void printBattleShip ( char[][] player){
        System.out.print("  ");
        for (int row = -1; row < 5; row++) {
            if (row > -1) {
                System.out.print(row + " ");
            }
            for (int column = 0; column < 5; column++) {
                if (row == -1) {
                    System.out.print(column + " ");
                } else {
                    System.out.print(player[row][column] + " ");
                }
            }
            System.out.println("");
        }
    }

    public static char[][] initArray ( int columns, int rows, char fill){
        char[][] arr = new char[columns][rows];
        //{{'a','b'},{'l','m'}};
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                //System.out.println(c+" "+r);
                arr[c][r] = fill;
            }
        }
        return arr;
    }

    public static char[][] alterArray ( char[][] array, int col2upt, int row2upt, char fill2upt){
        array[col2upt][row2upt] = fill2upt;
        return array;
    }

    public static char[][] updateArray (char[][] array){
        Scanner myObject = new Scanner(System.in);
        //System.out.println("enter two numbers");
        int col2upt = myObject.nextInt();
        int row2upt = myObject.nextInt();
        if (col2upt >= 0 & col2upt < 5 & row2upt >= 0 & row2upt < 5)
            if (array[col2upt][row2upt] != '@')
                array[col2upt][row2upt] = '@';
            else System.out.println("You already have a ship there. Choose different coordinates.");
        else System.out.println("Invalid coordinates. Choose different coordinates.");
        return array;
    }

    public static Object[] hitArray (char[][] target_array, char[][] other_players_LB, int current){
        Scanner myObject = new Scanner(System.in);
        System.out.println("Player "+current+", enter hit row/column:");
        int col2upt = myObject.nextInt();
        int row2upt = myObject.nextInt();
        boolean outOfBounds = false;
        boolean already = false;
        Object[] dwieMacierze = new Object[4];
        if (col2upt >= 0 & col2upt < 5 & row2upt >= 0 & row2upt < 5) {
            char A = other_players_LB[col2upt][row2upt];
            //do {
                switch (A) {
                    case ('-'):
                        System.out.println("PLAYER " + current + " MISSED!");
                        other_players_LB[col2upt][row2upt] = 'O';
                        target_array[col2upt][row2upt] = 'O';
                        break;
                    case ('@'):
                        System.out.println("PLAYER " + current + " HIT PLAYER " + next(current) + "’s SHIP!");
                        other_players_LB[col2upt][row2upt] = 'X';
                        target_array[col2upt][row2upt] = 'X';
                        break;
                    case ('X'):
                        System.out.println("You already fired on this spot. Choose different coordinates.");
                        already = true; // (same logic like out)
                    case ('O'):
                        System.out.println("You already fired on this spot. Choose different coordinates.");
                        already = true; // (same logic like out)
                }
            }
            //while (A == 'X'); //To DO WHILE tylko, jeśli chcemy żeby po strzale w to samo miejsce nie tracił kolejki.
            //Jeśli traci kolejkę to bez do while
        else {
            System.out.println("Invalid coordinates. Choose different coordinates.");
            outOfBounds = true;
        }

        dwieMacierze[0] = target_array;
        dwieMacierze[1] = other_players_LB;
        dwieMacierze[2] = outOfBounds;
        dwieMacierze[3] = already;
        return dwieMacierze;
    }


    public static boolean sameContent ( char[][] arr1, char[][] arr2){
        boolean answer = true;
        int arr1rows = arr1[0].length;
        int arr2rows = arr2[0].length;
        int arr1cols = arr1.length;
        int arr2cols = arr2.length;
        if (arr1rows == arr2rows & arr1cols == arr2cols) {
            for (int r = 0; r < arr1rows; r++)
                for (int c = 0; c < arr1cols; c++) {
                    //System.out.println(c+" "+r+" "+arr1[c][r] + " " + arr2[c][r]);
                    if (arr1[c][r] != arr2[c][r]) {
                        answer = false;
                        //System.out.println("mismatch spotted");
                        break;
                    }
                }
        } else {
            System.out.println("matrices have different dimensions");
            answer = false;
        }
        return answer;
    }

    public static char[][] copyArray ( char[][] arr1){
        boolean answer = true;
        int arr1rows = arr1[0].length;
        int arr1cols = arr1.length;
        char[][] arr2 = new char[arr1cols][arr1rows];
        for (int r = 0; r < arr1rows; r++)
            for (int c = 0; c < arr1cols; c++)
                arr2[c][r] = arr1[c][r];
        return arr2;
    }

    public static int ships_sunk (char[][] arr){
        int sunk = 0;
        int arr1rows = arr[0].length;
        int arr1cols = arr.length;
        //char[][] arr2 = new char[arr1cols][arr1rows];
        for (int r = 0; r < arr1rows; r++)
            for (int c = 0; c < arr1cols; c++)
                if (arr[c][r] == 'X')
                    sunk++;
        return sunk;
    }

    public static char[][] locationBoardsSetUp ( int n){
        char[][] LB = initArray(5, 5, '-');
        char[][] LBbefore = copyArray(LB);
        System.out.println("PLAYER "+ n +", ENTER YOUR SHIPS' COORDINATES.");
        //printBattleShip(LB);
        int Pset = 1;
        //while (Pset <= 5) {
        do {
            System.out.println("Enter ship "+ Pset +" location:");
            LB = updateArray(LB);
            //printBattleShip(LB);
            if (sameContent(LB, LBbefore))
            {}
            //System.out.println("same");
            else
                Pset += 1;
            LBbefore = copyArray(LB);
            //System.out.println(Pset);
        }
        while (Pset <= 5);
        printBattleShip(LB);
        return LB;
    }

    public static int next(int current){
        int next;
        if (current == 1) {next = 2;}
        else {next = 1;}
        return next;
    }
}
