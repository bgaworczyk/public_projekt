package demo1;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class PracaDomowa1 extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    boolean coding = true; // to distinguish the direction of data processing (in / out)

    @Override
    public void start(Stage primaryStage) {
        try {
            BorderPane root = new BorderPane();
            Scene scene = new Scene(root,400,340);
            
            scene.getStylesheets().add(getClass().getResource("pd1.css").toExternalForm());

            //-----------------------------------------------------------------------
            //CENTRAL PART
            VBox core = new VBox();
            TextField text1 = new TextField("tekst startowy");
            TextField text2 = new TextField();

            Label w = new Label("Wynik operacji"); w.setFont(Font.font(14));
            w.setPadding(new Insets(20, 0, 10, 0));

            Label z = new Label("Źródło"); z.setFont(Font.font(14));
            z.setPadding(new Insets(0, 0, 10, 0));
            Label empty2 = new Label(""); empty2.setFont(Font.font(8));

            //JToggleButton jbtSudokuGenerator = new JToggleButton("generate");
            Button buttonKopiuj = new Button("Kopiuj");
            Button buttonWykonaj = new Button("Wykonaj");

            HBox border = new HBox();
            border.setAlignment(Pos.CENTER_RIGHT);
            border.getChildren().add(buttonKopiuj);
            border.setPadding(new Insets(10,0,0,0));

            core.getChildren().addAll(z, text1, border, w, text2, empty2, buttonWykonaj);
            core.setPadding(new Insets(30, 60, 10, 40));
            ///----------------------------------------------------------------------------
            //RADIO
            RadioButton radio1 = new RadioButton("kodowanie");
            radio1.setPadding(new Insets(10, 0, 10, 0));
            RadioButton radio2 = new RadioButton("dekodowanie");
            radio1.setUserData("kodowanie");
            radio2.setUserData("dekodowanie");
            ToggleGroup tgroup = new ToggleGroup(); //to jest po to, żeby przyciski radiowe działały na zmianę (jeden on, drugi off). Toggle PL Przełącznik
            radio1.setToggleGroup(tgroup); //to jest po to, żeby przyciski radiowe działały na zmianę (jeden on, drugi off)
            radio2.setToggleGroup(tgroup); //to jest po to, żeby przyciski radiowe działały na zmianę (jeden on, drugi off)
            tgroup.selectedToggleProperty().addListener((ov, oldToggle, newToggle) -> {String toggleState = newToggle.getUserData().toString();
                //System.out.println(toggleState);
                if (toggleState == "dekodowanie") coding = false; else coding = true; System.out.println(coding);}
            );

            // RIGHT PART
            VBox rightBox = new VBox();
            rightBox.setPadding(new Insets(80, 20, 0, 0));
            Label labelOperation = new Label("Operacja"); z.setFont(Font.font(14));
            Label labelCoding= new Label("Kodowanie"); z.setFont(Font.font(14));
            Label labelDecoding = new Label("Dekodowanie"); z.setFont(Font.font(14));
            rightBox.getChildren().addAll(labelOperation, radio1, radio2);


            buttonKopiuj.setOnAction(event -> {System.out.println("kopiuj");
                        text2.setText(text1.getText());
                        text1.setText("");});

            buttonWykonaj.setOnAction(event -> {System.out.println("Wykonaj");
                if (coding)
                {
                    text2.setText(""); //to clean any previous works
                    text2.setText(encode(text1.getText()));
                    text1.setText("");
            }
                else
                {
                    text2.setText(""); //to clean any previous works
                    text2.setText(decode(text1.getText()));
                    text1.setText("");
                }}
            );


            root.setCenter(core);
            root.setRight(rightBox);//Two texts on each other
            primaryStage.setScene(scene);
            primaryStage.show();

        } catch(Exception e) {
            e.printStackTrace();
        }}

    private static String encode(String raw1){
        String encrypted = "";
            char current = '.';
            if (raw1.length() > 1) {
                int count = 1;
                char starter = raw1.charAt(0);
                encrypted = "";
                for (int i = 1; i < raw1.length(); i++) {
                    current = raw1.charAt(i);
                    if (raw1.charAt(i) != raw1.charAt(i - 1)) {
                        encrypted = encrypted + raw1.charAt(i - 1) + count + ",";
                        count = 1;
                    } else {
                        count += 1;
                    }
                    ;
                }
                encrypted = encrypted + current + count;
            } else if (raw1.length() == 1) {
                encrypted = raw1.charAt(0) + "1";
            }
        return encrypted;
    }

    private static String decode(String encrypted){
        String decrypted = "";
        try {
            char carrier = '_';
            int repetitions = 0;
            String[] splited = encrypted.split(",");
            for (int i = 0; i < splited.length; i++) {
                carrier = splited[i].charAt(0);
                repetitions = Integer.parseInt(splited[i].substring(1));
                //System.out.println(splited[i] + " -> " + carrier + " " + repetitions);
                for (int j = 0; j < repetitions; j++) {
                    decrypted = decrypted + carrier;
                }
            }
        }
        catch(Exception e){
            decrypted = "imposible to decode this";
        }
        return decrypted;
    }
}

