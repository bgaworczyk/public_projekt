package param;
import java.nio.BufferOverflowException;
import java.util.EmptyStackException;

	public class Stack {

		public static int MAXIMUM_CAPACITY = 10;
		private int size = 0;
		private int[] contents = new int[MAXIMUM_CAPACITY];
		public boolean isEmpty() {
			return size == 0;
		}
		public void push(int i) {
			if (size == MAXIMUM_CAPACITY) {
				throw new BufferOverflowException();
			}
			contents[size++] = i;
		}

		public int pop() {
			if (isEmpty()) {
				throw new EmptyStackException();
			}
			return contents[--size];
		}

		public int getSize() {
			return size;
		}

		public void clear() {
			int size = getSize();
			while (size > 0) {
				pop();
				size = getSize();
			}}

		public int getMaximumCapacity() {
			return MAXIMUM_CAPACITY;
		}

		public void setMaxCapacity(int max) {
			MAXIMUM_CAPACITY = max;
		};	
		

		public void setExpand(int expansionN, int valueConst) {
			//powiększanie stosu o zadany przyrost - pierwszy parametr mówi ile razy robimy push, 
			//drugi parametr mówi jaką wielkość wrzucamy w każdym pushu: = push(valueConst)			
			if (size + expansionN <= MAXIMUM_CAPACITY) {
				for (int i = 0; i < expansionN; i++) 
				{contents[size++] = valueConst;}}
			else
			{throw new BufferOverflowException();
			}
			}
		
		
		public void setFlexiLimit(int expansionN, int valueConst) {
			//w przypadku gdy liczba wrzucanych elementów implikuje przelanie stosu,
			//maksymalna pojemność jest odpowiedno zwiększana
			if 
			(size + expansionN > MAXIMUM_CAPACITY) { 
				MAXIMUM_CAPACITY = size + expansionN + 2; // 2 is margin
				int[] contents = new int[size + expansionN + 2]; 
				for (int i = 0; i < expansionN; i++) {			
				contents[size++] = valueConst;
				}
			}
		}
	}

		
		
		
		
	
		
				

