import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import java.nio.BufferOverflowException;
import java.util.EmptyStackException;
import param.Stack;

public class StackTests {

	
	@Test	
	public void newlyCreatedStackIsEmpty() {
		Stack s = new Stack();
		assertTrue(s.isEmpty());
	}

	@Test
	public void afterPushStackIsNoLongerEmpty() {
		Stack s = new Stack();
		s.push(1);
		assertFalse(s.isEmpty());
	}

	@Test
	public void afterPushAndPopStackIsEmptyAgain() {
		Stack s = new Stack();
		s.push(1);
		s.pop();
		assertTrue(s.isEmpty());
	}

	@Test
	public void emptyStackThrowsOnPop() {
		assertThrows(
				EmptyStackException.class,
				() -> {
					Stack s = new Stack();
					s.pop();
				}
		);
	}

	@Test
	public void popReturnsWhatWasPushed() {
		Stack s = new Stack();
		s.push(1234);
		assertEquals(1234, s.pop());
	}

	@Test
	public void stackDoesNotBecomeEmptyWhenThereWasLessPopThanPush() {
		Stack s = new Stack();
		s.push(1);
		s.push(2);
		s.pop();
		assertFalse(s.isEmpty());
	}

	@Test
	public void lastPopReturnsFirstPushedValue() {
		Stack s = new Stack();
		s.push(7);
		s.push(22);
		s.pop();
		assertEquals(7, s.pop());
	}

	@Test
	public void stackThrowsWhenTryingToPushMoreThanMaximumCapacity() {
		assertThrows(
				BufferOverflowException.class,
				() -> {
					Stack s = new Stack();
					for (int i = 0; i < Stack.MAXIMUM_CAPACITY + 1; ++i)
						s.push(i);
				}
		);
	}

	@Test
	public void testSizeStart() {
		Stack s = new Stack();
		int size = s.getSize();
		assertEquals(0, size);
	}

	@Test
	public void testSizePush() {
		Stack s = new Stack();
		s.push(14);
		s.push(51);
		int size = s.getSize();
		assertEquals(2, size);
	}

	@Test
	public void testSizePushAndPop() {
		Stack s = new Stack();
		s.push(7);
		s.push(9);
		s.push(12);
		s.push(3);
		s.pop();
		int expected = 3;
		int size = s.getSize();
		assertEquals(3, size);
	}

	@Test
	public void testClearFromMax() {
		Stack s = new Stack();
		for (int i = 0; i < Stack.MAXIMUM_CAPACITY; ++i)
			s.push(13);
		assertEquals(s.getSize(), Stack.MAXIMUM_CAPACITY);
		s.clear();
		assertTrue(s.isEmpty());
	}

	@Test
	public void testClearWhenEmpty() {
		Stack s = new Stack();
		s.clear();
		assertEquals(s.getSize(), 0);}

	@Test 
	public void testSetNewMaxCapacity() {
		Stack s = new Stack();
		s.setMaxCapacity(8);
		assertEquals(8, s.getMaximumCapacity());
	}
	
	@Test
	public void testExpandModest() 
	// na pusty stos wrzucam cztery siódemki. 
	//stos ma max cap = 10, nie jest oczekiwany throw exception
	{
		Stack s = new Stack();
		s.setMaxCapacity(10); // profilaktycznie ustawiam na domyślne 10, bo wcześniejszy test "testSetNewMaxCapacity()" może tu robić szum 
		assertEquals(s.getMaximumCapacity(),10);

		s.setExpand(4, 7); // 4 times I do push(7) 
		int expected = 4;
		assertEquals(expected, s.getSize());
	}
	
	@Test 
	public void testExpandTooMuch() 
	//wrzucam na stos "ręcznie" pięć wartości, 
	//następnie zadaje przyrost o 7 x stałą wartość (stała np. 1)
	//oczekiwany throw 
	{
		Stack s = new Stack();
		s.setMaxCapacity(10); // profilaktycznie ustawiam na domyślne 10, bo wcześniejszy test "testSetNewMaxCapacity()" może tu robić szum
		assertEquals(s.getMaximumCapacity(),10);  
		s.push(7);
		s.push(9);
		s.push(12);
		s.push(3);
		s.push(8);
		assertEquals(s.getSize(), 5);             //upewniam się, że mam 5 na stosie
		assertEquals(s.getMaximumCapacity(),10);   //upewniam się, że mam limit 10
		// no to teraz jak spróbuję wrzucić 7 stałych to stos rzuci wyjątkiem, 
		//lambda naruszy warunek 7+5 < = 10
		assertThrows(
				BufferOverflowException.class,
				() -> {
					s.setExpand(7, 1);
				}
		);
	}	
	
	@Test
	public void testExpandFlexi() 
	{
		Stack s = new Stack();
		
		//-----ustawiam boisko-------
		s.setMaxCapacity(10);
		s.setExpand(4, 7); // 4 times I do push(7) 
		assertEquals(4, s.getSize());
		assertEquals(s.getMaximumCapacity(),10); 
		//punkt wyjścia: mam stos o pojemności 10. mam na nim 4 elementy (siódemki)
		//WŁAŚCIWY TEST ZACZYNA SIĘ TUTAJ: teraz sprawdzę działanie metody
		//wrzucam 10 dwójek. oczekuję, że max capacity wzrośnie do 16 = 4+10+2 (2 to stały margines, taka fantazja), 
		//oczekuję, że na stosie będzie 14 elementów:
		s.setFlexiLimit(10, 2);
		assertEquals(16, s.getMaximumCapacity());
		assertEquals(14, s.getSize());
	}
	
}
	
