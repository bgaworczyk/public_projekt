package param;
import java.util.ArrayList;

public class Money {
    public static void main(String[] args){}
    private float fAmount;
    private String fCurrency;


    public Money(float amount, String currency) {
        fAmount = amount;
        fCurrency = currency;
    }

    public float amount() {
        return fAmount;
    }

    public String currency() {
        return fCurrency;
    }

    public Money add(Money m) {
        return new Money(amount() + m.amount(), currency());
    }

    public Money multiplyCurrency(int k) {
        return new Money(amount() * k, currency());
    }


    public boolean equals(Object anObject) {
        if (anObject instanceof Money) {
            Money a = (Money) anObject;
            return a.currency().equals(currency()) && amount() == a.amount();
        }
        return false;}

    public static float getFxQuote(String currencyToCheck, ArrayList<Money> notowania)
        {
            float quote = 1;
            for (Money kurs : notowania) {

                if (kurs.currency().equals(currencyToCheck))
                    quote = kurs.amount();
            }
            return quote;
        }

    public Money addAnyCurrency(Money any) {
        float converted;
        float dodawanaWalutaKursPLN = 1;
        float bazowaWalutaKursPLN = 1;

        ArrayList<Money> notowania = getNotowania();
        dodawanaWalutaKursPLN = getFxQuote(any.currency(), notowania);
        bazowaWalutaKursPLN = getFxQuote(currency(), notowania);
        converted = any.amount()*(dodawanaWalutaKursPLN/bazowaWalutaKursPLN);

        System.out.println("Bazowa waluta kurs w PLN = "+bazowaWalutaKursPLN+", dodawana waluta kurs w PLN = "+dodawanaWalutaKursPLN);
        System.out.println("Ile waluty dodawanej do wymiany? = "+any.amount()+" "+any.currency());
        System.out.println("Waluta dodawana po wymianie = "+converted+" "+currency());
        System.out.println("Waluty bazowej przed dodawaniem było = "+amount()+" "+currency());
        System.out.println("Suma w walucie bazowej:");
        return new Money((float) (Math.round((amount() + converted)*100)/100.00), currency());
    }

    public static ArrayList<Money> getNotowania() {
        ArrayList<Money> notowania = new ArrayList<>();
        notowania.add(new Money((float) 1.0000, "PLN"));
        notowania.add(new Money((float) 4.4018, "USD"));
        notowania.add(new Money((float) 2.9890, "AUD"));
        notowania.add(new Money((float) 3.2486, "CAD"));
        notowania.add(new Money((float) 4.6899, "EUR"));
        notowania.add(new Money((float) 4.7679, "CHF"));
        notowania.add(new Money((float) 5.2957, "GBP"));
        notowania.add(new Money((float) 0.4213, "SEK"));
        return notowania;
    }
}


