import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static param.Money.getNotowania;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import param.Money;
import java.util.ArrayList;

public class TestMoney {

    @Test
    public void testSimpleAdd() {
        Money m12CHF = new Money(12, "CHF"); //
        Money m14CHF = new Money(14, "CHF");
        Money expected = new Money(26, "CHF");
        Money result = m12CHF.add(m14CHF); //
        assertTrue(expected.equals(result)); //
    }

    @Test
    public void testEquals() {
        Money m12CHF = new Money(12, "CHF");
        Money m14CHF = new Money(14, "CHF");
        Money m12PLZ = new Money(14, "PLZ");
        assertTrue(!m12CHF.equals(null));
        assertEquals(m12CHF, m12CHF);
        assertEquals(m12CHF, new Money(12, "CHF"));
        assertTrue(!m12CHF.equals(m14CHF));
        assertTrue(!m12CHF.equals(m12PLZ));
    }

    @Test
    public void testMultiplyCurrency() {
        Money m12CHF = new Money(12, "CHF"); //

        int k = 3;
        Money expected = new Money(36, "CHF");
        Money result = m12CHF.multiplyCurrency(k); //
        assertTrue(expected.equals(result)); //

        int uno = 1;
        Money result2 = m12CHF.multiplyCurrency(uno); //
        assertTrue(m12CHF.equals(result2)); //
    }

    @ParameterizedTest
    @CsvSource({"10,PLN,10,SEK", "10,GBP, 11,CHF", "20,USD, 33,AUD", "10, SEK, 0, EUR", "0, EUR, 10, SEK"})
    public void testAddAnyCurrency(int a, String currencyA, int b, String currencyB) {
        Money bazowa = new Money(a, currencyA);
        Money dodawana = new Money(b, currencyB);
        ArrayList<Money> notowania = getNotowania();
        float kursA = getQuote(currencyA, notowania);
        float kursB = getQuote(currencyB, notowania);
        Money expected = new Money ((float) Math.round(100*(a+ b*(kursB/kursA)))/100, currencyA);
        Money result = bazowa.addAnyCurrency(dodawana);
        System.out.println(result.amount()+" "+result.currency());
        assertEquals(expected, result);
        System.out.println(" ");
    }

    private float getQuote(String currencyToCheck, ArrayList<Money> notowania) {
        float quote = 1;
        for (Money kurs : notowania) {if (kurs.currency().equals(currencyToCheck)) quote = kurs.amount();}
        return quote;
    }}


