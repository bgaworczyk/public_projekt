package sockets;
//you can run this from InteliJ (for example) or likewise from Eclipse 
//but first start ServerStartsFirst.java (from Eclipse)

import java.net.*;
import java.io.*;
public class ClientStartsSecond{
  public static void main(String args[])throws Exception{
      Socket s=new Socket("localhost",9001);
      DataInputStream din=new DataInputStream(s.getInputStream());
      DataOutputStream dout=new DataOutputStream(s.getOutputStream());
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

      System.out.println("Przekaż do serwera polecenie do obliczenia np.: 1 + 3 [enter]");
      String str="",str2="";
      while(!str.equals("stop")){
          str=br.readLine();
          dout.writeUTF(str);
          dout.flush();
          str2=din.readUTF();
          System.out.println("Wynik obliczeń: "+str2);
      }
      dout.close();
      din.close();
      br.close();
      s.close();
  }}