package sockets;
//running this from Eclipse. ServerStartsFirst starts before ClientStartsSecond 

import java.net.*;  
import java.io.*;
import jdk.jshell.JShell;
import jdk.jshell.SnippetEvent;
import java.util.List;

public class ServerStartsFirst {

public static void main(String args[])throws Exception{  
ServerSocket ss=new ServerSocket(9001);  
Socket s=ss.accept();  
DataInputStream din=new DataInputStream(s.getInputStream());  
DataOutputStream dout = new DataOutputStream(s.getOutputStream());  

String str=""; 
while(!str.equals("stop")){  
str=din.readUTF();  
System.out.println("client says: "+str);  
dout.writeUTF(compute(str));
dout.flush();  
}
dout.close();
din.close();  
s.close();  
ss.close();  
}


public static String compute(String polecenie) {
        String output = null;
		JShell jshell = JShell.create();
        try (jshell) { // automatyczne zwalnianie zasobów we frazie try-catch, od JDK9
            List<SnippetEvent> events = jshell.eval(polecenie);
            for (SnippetEvent e : events) {
                if (e.causeSnippet() == null) {
                    switch (e.status()) {
                        case VALID:
                            if (e.value() != null) {
                                System.out.printf("%s = %s\n", polecenie, e.value());
                                output = (String) e.value();
                            }
                            break;
                        default: System.out.printf("Error\n"); output = "Error"; 
                        break;
                    }}}}
        return output;
	}
}

