/**
 * 
 */
/**
 * @author bgawo
 *
 */
module ClientServer {
	requires jdk.jshell;
}