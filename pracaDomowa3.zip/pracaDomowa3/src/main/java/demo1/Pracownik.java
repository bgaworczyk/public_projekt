package demo1;

//Imię, Nazwisko, Nr pokoju

public class Pracownik implements Comparable<Pracownik> {
    private String imie;
    private String nazwisko;
    private int nrPokoju;


    public Pracownik(String imie, String nazwisko, int nrPokoju)
    {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.nrPokoju = nrPokoju;
    }

    public String getImie () {return imie;}
    public String getNazwisko () {return nazwisko;}
    public int getNumerPokoju () {return nrPokoju;}
    public int compareTo(Pracownik other) {return Double.compare(nrPokoju, other.nrPokoju);}

}


//public void setNazwisko(String imie) {this.nazwisko = nazwisko;}
// public void setNumerPokoju (int nrPokoju) {this.nrPokoju = nrPokoju;};