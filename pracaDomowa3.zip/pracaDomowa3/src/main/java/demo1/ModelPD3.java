package demo1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.*;

public class ModelPD3 extends Application {
    static String imionaModel = "";
    static String nazwiskaModel = "";
    static String numeryModel = "";


    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(ModelPD3.class.getResource("pd3-view2.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 540, 480);
        stage.setTitle("Zasoby");
        stage.setScene(scene);
        stage.show();
    }


    public static void main(String[] args) {
        String myTextFile = "zasoby3.txt";

        Pracownik[] pracownicy = getPracowniks();

        for (Pracownik e : pracownicy) {
            String outputRow = e.getImie() + ", " + e.getNazwisko() + ", " + e.getNumerPokoju();
            writeToTxt(outputRow, myTextFile);

            System.out.println(outputRow);
            imionaModel = imionaModel + e.getImie() + "\n";
            nazwiskaModel = nazwiskaModel + e.getNazwisko() + "\n";
            numeryModel = numeryModel + e.getNumerPokoju() + "\n";
        }


        //próba wczytania z pliku
        String textFileContentBelow = null;
        try {
            textFileContentBelow = readFile(myTextFile);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("----to są dane z pliku:\n" + textFileContentBelow);

        launch();

    }

    private static Pracownik[] getPracowniks() {
        var pracownicy = new Pracownik[4];

        pracownicy[0] = new Pracownik("Jan", "Nowak", 5);
        pracownicy[1] = new Pracownik("Barbara", "Lipko", 4);
        pracownicy[2] = new Pracownik("Tamara", "Jones", 3);
        pracownicy[3] = new Pracownik("Stefan", "Wawelski", 13);
        return pracownicy;
    }


    public static void writeToTxt(String text, String filename) //
    {
        try {
            FileWriter writer = new FileWriter(filename, true);
            PrintWriter printer = new PrintWriter(writer);
            printer.printf("%s" + "%n", text);
            printer.close();
            writer.close();
        } catch (IOException ioe) {
            System.out.println("zapis do pliku nie udał się");
        }
    }

    private static String readFile(String file) throws IOException {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line = null;
            StringBuilder stringBuilder = new StringBuilder();
            String ls = System.getProperty("line.separator");

            try {
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                    stringBuilder.append(ls);
                }
            } finally {
                reader.close();
            }
            return stringBuilder.toString();
        }
        catch (IOException ioe) {
            System.out.println("zapis do pliku nie udał się");
            return "empty";
            }
        }

}




