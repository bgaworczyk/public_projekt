package demo1;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.lang.Math;

import static java.lang.Float.parseFloat;

public class ControllerPD3 {
    @FXML
    private Label buttonValue;

    @FXML
    private TextField computations;

    @FXML
    private TextArea imiona;

    @FXML
    private TextArea nazwiska;

    @FXML
    private TextArea numery;

    @FXML
    public void onDuo() {
        imiona.setText(ModelPD3.imionaModel);
        nazwiska.setText(ModelPD3.nazwiskaModel);
        numery.setText(ModelPD3.numeryModel);
    }
    }
