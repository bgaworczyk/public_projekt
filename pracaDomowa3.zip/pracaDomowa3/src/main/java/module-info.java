module com.example.demo {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.jshell;


    exports demo1;
    opens demo1 to javafx.fxml;
}