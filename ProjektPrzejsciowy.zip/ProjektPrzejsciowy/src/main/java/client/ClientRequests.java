package client;
import java.net.*;
import java.io.*;

public class ClientRequests {
    public static String computeRemote(String toCompute)throws Exception{
        Socket s=new Socket("localhost",9001);
        DataInputStream din=new DataInputStream(s.getInputStream());
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        String str="",str2="",str3="";
        String result = "";
        System.out.println(din.readUTF()); //hello
        while(true){
            str=toCompute;
            dout.writeUTF(str);
            dout.flush();
            str2=din.readUTF();

            s = new Socket("localhost", 9001);
            din = new DataInputStream(s.getInputStream());
            dout = new DataOutputStream(s.getOutputStream());
            br = new BufferedReader(new InputStreamReader(System.in));
            str3 = din.readUTF();

            return str2;
        }
    }
}

