package client;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import static java.lang.Float.parseFloat;

public class ClientCalculatorController {
    @FXML
    private Label buttonValue;

    @FXML
    private TextField computations;

    @FXML
    public void onUno() {computations.setText(computations.getText() + "1");}
    public void onDuo() {computations.setText(computations.getText() + "2");}
    public void onTres() {computations.setText(computations.getText() + "3");}
    public void onQuatro() {computations.setText(computations.getText() + "4");}
    public void onFive() {computations.setText(computations.getText() + "5");}
    public void onSix() {computations.setText(computations.getText() + "6");}
    public void onSeven() {computations.setText(computations.getText() + "7");}
    public void onEight() {computations.setText(computations.getText() + "8");}
    public void onNine() {computations.setText(computations.getText() + "9");}
    public void onMultiply() {computations.setText(computations.getText() + "*");}
    public void onAdd() {computations.setText(computations.getText() + "+");}
    public void onLeftBracket() {computations.setText(computations.getText() + "(");}
    public void onRightBracket() {computations.setText(computations.getText() + ")");}
    public void onDot() {computations.setText(computations.getText() + ".");}
    public void onSubtract() {computations.setText(computations.getText() + "-");}
    public void onDivide() throws Exception { float numerator = parseFloat(ClientRequests.computeRemote(computations.getText()));
        computations.setText(numerator + "/");}
    public void onZero() {computations.setText(computations.getText() + "0");}
    public void onReturn() throws Exception {//computations.setText(Calculator.compute(computations.getText()));
                            computations.setText(ClientRequests.computeRemote(computations.getText()));}
    public void onErase() {computations.setText("");}
    public void onRoot()//note this one uses other than Jshell method

        throws Exception { String outcome = ClientRequests.computeRemote(computations.getText());
        double root = Math.sqrt(parseFloat(outcome));
        computations.setText(""+root);
    }
}