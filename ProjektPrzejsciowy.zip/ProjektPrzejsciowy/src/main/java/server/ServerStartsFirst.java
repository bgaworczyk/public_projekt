package server;

import java.io.*;
import java.net.*;

public class ServerStartsFirst {

    public static void main(String[] args) throws IOException
    {
        ServerSocket ss = new ServerSocket(9001);

        ServerClientHandler[] serverClientHandlers = new ServerClientHandler[1000];

        int thread_number = 0;
        Socket s = null;

        do {
            serverClientHandlers = new ServerClientHandler[1000];
            s = ss.accept();
            serverClientHandlers[thread_number] = new ServerClientHandler(
                    thread_number,
                    s,
                    new DataInputStream(s.getInputStream()),
                    new DataOutputStream(s.getOutputStream())
            );
            serverClientHandlers[thread_number].start();
            thread_number += 1;
        }
        while
        (thread_number < 1000);
    }
}