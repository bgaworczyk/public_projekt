package server;

import java.net.*;
import java.io.*;

class ServerClientHandler extends Thread
{
    DataInputStream dis;
    DataOutputStream dos;
    Socket s;
    int thread_number;

    public ServerClientHandler(int thread_number, Socket s, DataInputStream dis, DataOutputStream dos)
    {
        this.thread_number = thread_number;
        this.s = s;
        this.dis = dis;
        this.dos = dos;
    }

    @Override
    public void run()
    {
        String str="";
        try {
            dos.writeUTF("Thread:" + thread_number);
            str = dis.readUTF();
            dos.writeUTF(""+ServerCompute.compute(str));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}