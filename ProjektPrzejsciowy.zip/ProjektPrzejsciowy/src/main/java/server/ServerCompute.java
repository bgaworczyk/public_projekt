package server;
import java.util.List;
import jdk.jshell.JShell;
import jdk.jshell.SnippetEvent;

public class ServerCompute {

    public static String compute(String polecenie) {
        String output = null;
        JShell jshell = JShell.create();
        try (jshell) { // automatyczne zwalnianie zasobów we frazie try-catch, od JDK9
            List<SnippetEvent> events = jshell.eval(polecenie);
            for (SnippetEvent e : events) {
                if (e.causeSnippet() == null) {
                    switch (e.status()) {
                        case VALID:
                            if (e.value() != null) {
                                System.out.printf("%s = %s\n", polecenie, e.value());
                                output = (String) e.value();
                            }
                            break;
                        default: System.out.printf("Error\n"); output = "Error";
                            break;
                    }}}}
        return output;
    }
}
