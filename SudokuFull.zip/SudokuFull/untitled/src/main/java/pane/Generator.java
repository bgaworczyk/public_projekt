package pane;

import java.util.*;

public class Generator {
    public static void main(String[] args) {
        char[][] sudokuIreceived = Sudoku();
        System.out.println("---------------");
        printGrid(sudokuIreceived);

    }

    private static char[][] setGrid ( int size){
        char[][] square = new char[size][size];
        for (int row = 0; row < size; row++) {
            for (int column = 0; column < size; column++) {
                char toInsert = '.';
                square[row][column] = toInsert;
            }
        }
        return square;
    }

    private static ArrayList<int[]> updateEmptyCells ( char[][] sq){
        ArrayList<int[]> emptyCells = new ArrayList<>();
        for (int row = 0; row < 9; row++) {
            for (int column = 0; column < 9; column++) {
                int[] freeCell = new int[2];
                freeCell[0] = row;
                freeCell[1] = column;
                if (sq[row][column] == '.')
                    emptyCells.add(freeCell);
            }
        }
        return emptyCells;
    }

    private static ArrayList<Integer> availableCommon (ArrayList < Integer > one, ArrayList < Integer > two){
        //common part  of two lists
        ArrayList<Integer> availableForRand = one;
        ArrayList<Integer> availableIntegersR9C9 = two;
        ArrayList<Integer> common = new ArrayList<>(Arrays.asList());

        for (int e : availableForRand) {
            if (availableIntegersR9C9.contains(e)) {
                common.add(e);
            }
        }
        return common;
    }

    // this loop saturates the grid;
    public static char[][] gridGenerator ( char[][] sq, int leaveForUser, ArrayList<int[]>emptyCell){
        int free = freeCellsCounter(sq);
        do {
            for (int rowGroup = 0; rowGroup < 3; rowGroup++) {
                for (int colGroup = 0; colGroup < 3; colGroup++) {
                    sq = singleDice2(sq, rowGroup, colGroup, emptyCell);
                    free = freeCellsCounter(sq);
                    System.out.println("Free cells after = " + free);
                }
            }
        }
        while (free > leaveForUser);
        return sq;
    }


    static void printGrid(char[][] square){
        int squareSize = square.length;
        for (int row = 0; row < squareSize; row++) {
            for (int column = 0; column < squareSize; column++) {
                char cell = square[row][column];
                if ((int) cell >= 0 & (int) cell < 10) {
                    System.out.print((int) cell + " ");
                }
                //else if ((int) cell == 0) {System.out.print('#'+" ") ;}
                else {
                    System.out.print(cell + " ");
                }
            }
            System.out.println("");
        }
    }

    private static int freeCellsCounter ( char[][] nineSq){
        int freeCells = 81;
        for (int row = 0; row < 9; row++) {
            for (int column = 0; column < 9; column++) {
                if (nineSq[row][column] != '.') freeCells--;
            }
        }
        return freeCells;
    }

    private static char[][] LegalDiceUpdate ( char[][] sq, int row, int col){
        int legalDice = randLegal(sq, row, col);
        if (sq[row][col] == '.' && legalDice != 0) //
        {
            char[][] grid_after = cellWriter(sq, row, col, (char) legalDice);
            return grid_after;
        } else {
            System.out.println("either cell not empty or no available choices for dice");
            return sq;
        }
    }


    public static char[][] Sudoku() {
        char[][] sq = setGrid(9);
        ArrayList<int[]> emptyCells = updateEmptyCells(sq);
        //System.out.println(emptyCells.size());
        sq = gridGenerator(sq, 72, emptyCells);
        printGrid(sq);

        do {
            emptyCells = updateEmptyCells(sq);
            System.out.println("\nempty cells yet:" + emptyCells.size());
            Random rand = new Random();
            int randomEmptyCellIndex = rand.nextInt(emptyCells.size());
            int[] randomEmptyCell = emptyCells.get(randomEmptyCellIndex);
            int randRow = randomEmptyCell[0];
            int randCol = randomEmptyCell[1];
            sq = LegalDiceUpdate(sq, randRow, randCol);
            printGrid(sq);
        }
        while (emptyCells.size() > 18);
        return sq;
    }

        private static char[][] scanerToArray ( char[][] sq){
            int freeCells = 81;
            Scanner myObject = new Scanner(System.in);
            //System.out.println("enter three numbers between 1 and 9: row, col, val");

            int row2upt = myObject.nextInt();
            int col2upt = myObject.nextInt();
            int val2upd = myObject.nextInt();
            System.out.println(row2upt + " " + col2upt + " " + val2upd);
            sq = checkAndUpdate(sq, row2upt, col2upt, val2upd);
            printGrid(sq);
            return sq;
        }

        public static int determine () {
            Random rand = new Random();
            int random = rand.nextInt(10);
            return random;
        }


        private static char[][] cellWriter ( char[][] square, int y, int x, char fill){
            square[y][x] = fill;
            return square;
        }

        private static char[] sliceCol ( char[][] square, int colNum){
            char[] col2yield = new char[square.length];
            System.out.print("Col " + colNum + ">  ");
            for (int r = 0; r < square.length; r++) {
                col2yield[r] = square[r][colNum];
            }
            return col2yield;
        }

        private static char[] sliceRow ( char[][] square, int rowNum){
            char[] row2yield = new char[square.length];
            System.out.print("Row " + rowNum + ">  ");
            for (int c = 0; c < square.length; c++) {
                row2yield[c] = square[rowNum][c];
            }
            return row2yield;
        }

        private static void printRC ( char[] row_or_column){
            for (int i = 0; i < row_or_column.length; i++) {
                if ((int) row_or_column[i] >= 0 & (int) row_or_column[i] < 10) {
                    System.out.print((int) row_or_column[i] + " ");
                } else {
                    System.out.print(row_or_column[i] + " ");
                }
            }
        }


        private static char[][] slice3x3 ( char[][] square, int rowGroup, int colGroup){
            // rowGroup possible values = {0,1,2}. Same for colGroup.
            // e.g. 0 and 0 means return upper left 3x3 slice (from 9x9).
            // 1 and 1 means central slice (from 9x9)");
            char[][] slice3x3toYield = new char[3][3];

            ArrayList<Integer> rows = mapGroupToAddress(rowGroup);
            //System.out.println(rows);
            ArrayList<Integer> cols = mapGroupToAddress(colGroup);
            //System.out.println(cols);

            int sliceCol = 0;
            int sliceRow = 0;

            for (Integer r : rows) {
                for (Integer c : cols) {
                    slice3x3toYield[sliceRow][sliceCol] = square[r][c];
                    sliceCol++;
                }
                sliceCol = 0;
                //System.out.println("");
                sliceRow++;
            }

            return slice3x3toYield;
        }

        private static ArrayList<Integer> mapGroupToAddress ( int Group){
            Dictionary map = new Hashtable();
            List<Integer> uno = new ArrayList<>();
            uno.add(0);
            uno.add(1);
            uno.add(2);
            List<Integer> duo = new ArrayList<>();
            duo.add(3);
            duo.add(4);
            duo.add(5);
            List<Integer> tre = new ArrayList<>();
            tre.add(6);
            tre.add(7);
            tre.add(8);
            map.put(0, uno);
            map.put(1, duo);
            map.put(2, tre);
            return (ArrayList<Integer>) map.get(Group);
        }

        private static boolean can_I_insertInt ( char[] col_or_row_to_check, int toInsert){
            boolean canIns = true;
            for (int j = 0; j < col_or_row_to_check.length; j++) {
                if ((int) col_or_row_to_check[j] == toInsert) {
                    canIns = false;
                    //System.out.println("\nSorry, it already contains " + toInsert);
                    break;
                }
            }
            if (canIns == true) {
                //System.out.println("\nNo obstacles to insert " + toInsert);
            }
            return canIns;
        }

        private static boolean can_I_insertTo3x3 ( char[][] grid_to_check, int toInsert){
            boolean canIns = true;
            for (int j = 0; j < grid_to_check.length; j++) {
                if (can_I_insertInt(sliceRow(grid_to_check, j), toInsert) == false) {
                    canIns = false;
                    break;
                }
            }
            return canIns;
        }

        private static int mapCellToGroup ( int rowCelNum){
            int group;
            if (rowCelNum < 3) group = 0;
            else if (rowCelNum < 6) group = 1;
            else group = 2;
            return group;
        }

        static boolean cellEmpty ( char[][] grid, int row, int col){
            boolean Empty = true;
            if (grid[row][col] == '.') System.out.println("cellEmpty");
            else {
                System.out.println("cellTaken");
                Empty = false;
            }
            return Empty;
        }


        private static boolean canI ( char[][] grid, int row, int col, int val){
            //This function evaluates triple condition to insert val into cell,
            //by checking IF (row AND col AND 3x3slice) accepts val
            // (i.e. no value yet in either row, col, 3x3slice

            // check if I can insert this val to row
            char[] seeRow = sliceRow(grid, row);
            printRC(seeRow);
            boolean boolRow = can_I_insertInt(seeRow, val);
            System.out.println(boolRow + " " + val);

            // check if I can insert this val to col
            System.out.println(" ");
            char[] seeCol = sliceCol(grid, col);
            printRC(seeCol);
            boolean boolCol = can_I_insertInt(seeCol, val);
            System.out.println(boolCol + " " + val);

            //determine the rowGroup and celGroup to slice 3x3 grid
            int rowGroup = mapCellToGroup(row);
            int colGroup = mapCellToGroup(col);

            // check if val can ve inserted to 3x3
            char[][] s33 = slice3x3(grid, rowGroup, colGroup);
            printGrid(s33);
            boolean bool33 = can_I_insertTo3x3(s33, val);
            //System.out.println("3X3 grid check: \n" + bool33);


            boolean empty = cellEmpty(grid, row, col);
            //System.out.println("check if cell available: " + empty);

            boolean cellQuatroBool = (boolCol & boolRow & bool33 & empty);
            //System.out.println("quarto check: \n" + cellQuatroBool);

            if (cellQuatroBool == true) {
                System.out.println(val + " can be inserted in cell");
            } else {
                System.out.println(val + " can not be inserted in cell");
            }
            return cellQuatroBool;
        }

        private static char[][] checkAndUpdate ( char[][] grid, int row, int col, int val){
            if (canI(grid, row, col, val)) {
                char[][] grid_after = cellWriter(grid, row, col, (char) val);
                return grid_after;
            } else return grid;
        }

        private static int[] rAndC ( int rowGroup, int colGroup){
            //this method dices r and c within 3x3 square but returns coordinates of 9x9 after rowGroup, colGroup adjustment
            //colGroup is sth like left, central, right - but expressed as 0,1,2
            //rowGroup is sth like top, central, low - but expressed as 0,1,2
            //this method is used to assure each 3x3 box has random 'x' cell which is not available for inserting numbers;
            Random rand = new Random();
            int diceRow = rand.nextInt(3) + (rowGroup * 3);
            int diceCol = rand.nextInt(3) + (colGroup * 3);
            //System.out.print("\n-------\n");
            //System.out.print(diceRow + " " + diceCol + "\n");
            //System.out.print("\n-------\n");
            int[] rAndC = new int[2];
            rAndC[0] = diceRow;
            rAndC[1] = diceCol;
            return rAndC;
        }

        private static ArrayList<Integer> availables ( char[][] square33){
            //method returns list of integers that are acceptable value to be diced and inserted into 3x3,
            // (somewhere in this 3x3 as row and col are diced elsewhere;)
            //this is to exclude numbers that are already in 3x3 box from being returned as a diced value
            ArrayList<Integer> availableIntegers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));

            for (int row = 0; row < 3; row++) {
                for (int column = 0; column < 3; column++) {
                    char cell = square33[row][column];
                    if ((int) cell > 0 & (int) cell < 10) {
                        System.out.println((int) cell + "  " + availableIntegers);
                        availableIntegers.remove(Integer.valueOf((int) cell));
                    }
                }
            }
            return availableIntegers;
        }


        private static ArrayList<Integer> availableRow9Col9 ( char[][] square99, int rowNum, int intColNum){
            //method returns list of integers that are acceptable value to be diced and inserted into 3x3,
            // (somewhere in this 3x3 as row and col are diced elsewhere;)
            //this is to exclude numbers that are already in 3x3 box from being returned as a diced value
            ArrayList<Integer> availableIntegersR9C9 = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));

            char[] seeRow = sliceRow(square99, rowNum);
            char[] seeCol = sliceRow(square99, intColNum);

            System.out.println("check col");
            for (int row = 0; row < 9; row++) {
                char cell = seeCol[row];
                System.out.println(cell);

                if ((int) cell > 0 & (int) cell < 10) {
                    System.out.println((int) cell + "  " + availableIntegersR9C9);
                    availableIntegersR9C9.remove(Integer.valueOf((int) cell));
                }
            }

            System.out.println("check row");
            for (int col = 0; col < 9; col++) {
                char cell = seeRow[col];
                //System.out.println(cell);
                if ((int) cell > 0 & (int) cell < 10) {
                    //System.out.println((int) cell + "  " + availableIntegersR9C9);
                    availableIntegersR9C9.remove(Integer.valueOf((int) cell));
                }
            }
            return availableIntegersR9C9;
        }

        private static char[][] singleDice2 ( char[][] nineSq, int rowGroup, int colGroup,
        ArrayList<int[]> emptyCells)
        {
            //method inserts 'x' value into large grid and mirror this in its slice
            //the new value is inserted into random row and coll from indicated 3x3 chunk.
            //this is to make sure 'x' cells are distributed evenly
            char[][] sq3; // get 3x3 slice from 9x9 by rowGroup, coLGroup
            int[] t1 = rAndC(rowGroup, colGroup); // select randomly coordinates within 3x3 slice
            int rowRand = t1[0];
            int colRand = t1[1];
            nineSq = cellWriter(nineSq, rowRand, colRand, 'x'); // udpade large 9x9 square

            int[] freeCell = new int[2];
            freeCell[0] = rowRand;
            freeCell[1] = colRand;
            emptyCells.remove(freeCell);

            printGrid(nineSq);
            System.out.println("______");

            sq3 = slice3x3(nineSq, rowGroup, colGroup);
            printGrid(sq3);
            System.out.println("______");

            return nineSq;
        }


        public static char[][] userInputWhile ( char[][] sq){
            int free = freeCellsCounter(sq);
            do {
                scanerToArray(sq);
                //System.out.println("Free cells = " + free);
            }
            while (free > 0);
            return sq;
        }

        private static ArrayList<Integer> whatIsLegal ( char[][] sq, int row, int col)
        //returns list of integers that qualify for insert
        {
            ArrayList<Integer> legalIntegers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
            ArrayList<Integer> TakenIntegers = new ArrayList<>();

            //show me involved col
            char[] seeCol = sliceCol(sq, col);
            System.out.println("seeCol = ");
            printRC(seeCol);
            System.out.println("\n");
            //print taken integers in col
            ArrayList<Integer> integersTakenCol = takenInRowOrColl(seeCol);
            //System.out.println("integers in col " + integersTakenCol);

            // show me involved row
            char[] seeRow = sliceRow(sq, row);
            System.out.println("seeRow = ");
            printRC(seeRow);
            System.out.println("\n");
            //print row
            //print taken integers in row
            ArrayList<Integer> integersTakenRow = takenInRowOrColl(seeRow);
            //System.out.println("integersTakenRow  " + integersTakenRow);

            //conclude the group for box
            int rowGroup = mapCellToGroup(row);
            int colGroup = mapCellToGroup(col);

            //show me involved 3x3 box
            char[][] s33 = slice3x3(sq, rowGroup, colGroup);
            printGrid(s33);
            ArrayList<Integer> integersTakenBox = boxToList(s33);
            System.out.println("integers in box " + integersTakenBox);
            //print taken integers in box
            // summarize
            //

            for (Integer i : integersTakenBox) {
                TakenIntegers.add(i);
                legalIntegers.remove(i);
            }
            for (Integer i : integersTakenRow) {
                TakenIntegers.add(i);
                legalIntegers.remove(i);
            }
            for (Integer i : integersTakenCol) {
                TakenIntegers.add(i);
                legalIntegers.remove(i);
            }
            //System.out.println("taken integers summary: " + TakenIntegers);
            //System.out.println("legal integers for dice: " + legalIntegers);
            return legalIntegers;
        }

        private static int randLegal ( char[][] sq, int row, int col)
        {
            int legalDice;
            ArrayList<Integer> legalIntegers = whatIsLegal(sq, row, col);
            if (legalIntegers.size() > 0) {
                Random rand = new Random();
                int randomIndex = rand.nextInt(legalIntegers.size());
                legalDice = legalIntegers.get(randomIndex);
            } else
                legalDice = 0;
            return legalDice;
        }

        private static ArrayList<Integer> boxToList ( char[][] sq){
            ArrayList<Integer> integersUsedInBox = new ArrayList<>();
            for (int row = 0; row < 3; row++) {
                for (int column = 0; column < 3; column++) {
                    char cell = sq[row][column];
                    if ((int) cell > 0 & (int) cell < 10) {
                        integersUsedInBox.add((int) cell);
                    }
                }
            }
            return integersUsedInBox;
        }

        private static ArrayList<Integer> takenInRowOrColl ( char[] rowOrCol){
            ArrayList<Integer> integersUsedInROC = new ArrayList<Integer>();
            for (int i = 0; i < 9; i++) {
                char cell = rowOrCol[i];
                if ((int) cell > 0 && (int) cell < 10) {
                    integersUsedInROC.add((int) cell);
                }
            }
            return integersUsedInROC;
        }
    }
