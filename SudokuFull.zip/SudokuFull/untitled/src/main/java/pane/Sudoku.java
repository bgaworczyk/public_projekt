package pane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Sudoku extends JFrame {
    public Sudoku() {
        JPanel root = new JPanel();
        root.setLayout(new FlowLayout());
        setSize(300, 360);

        JPanel content = new JPanel();
        content.setLayout(new GridLayout(3,3));

        JButton UL = new JButton("1");
        JButton UM = new JButton("2");
        JButton UR = new JButton("3");
        JButton ML = new JButton("4");
        JButton MM = new JButton("5");
        JButton MR = new JButton("6");
        JButton LL = new JButton("7");
        JButton LM = new JButton("8");
        JButton LR = new JButton("9");

        content.add(UL); //upper left, etc.
        content.add(UM);
        content.add(UR);
        content.add(ML);
        content.add(MM);
        content.add(MR);
        content.add(LL);
        content.add(LM);
        content.add(LR);

        String g = " 1 ";
        JTextField t00 = new JTextField(g);
        JTextField t01 = new JTextField(g);
        JTextField t02 = new JTextField(g);
        JTextField t10 = new JTextField(g);
        JTextField t11 = new JTextField(g);
        JTextField t12 = new JTextField(g);
        JTextField t20 = new JTextField(g);
        JTextField t21 = new JTextField(g);
        JTextField t22 = new JTextField(g);

        JPanel textGridUL = new JPanel();
        textGridUL.setLayout(new GridLayout(3,3));
        textGridUL.add(t00);
        textGridUL.add(t01);
        textGridUL.add(t02);
        textGridUL.add(t10);
        textGridUL.add(t11);
        textGridUL.add(t12);
        textGridUL.add(t20);
        textGridUL.add(t21);
        textGridUL.add(t22);
        UL.add(textGridUL);
        UL.setMargin(new Insets(1, 1, 1, 1));

        String h = " 2 ";
        JTextField t03 = new JTextField(h);
        JTextField t04 = new JTextField(h);
        JTextField t05 = new JTextField(h);
        JTextField t13 = new JTextField(h);
        JTextField t14 = new JTextField(h);
        JTextField t15 = new JTextField(h);
        JTextField t23 = new JTextField(h);
        JTextField t24 = new JTextField(h);
        JTextField t25 = new JTextField(h);

        JPanel textGridUM = new JPanel();
        textGridUM.setLayout(new GridLayout(3,3));
        textGridUM.add(t03);
        textGridUM.add(t04);
        textGridUM.add(t05);
        textGridUM.add(t13);
        textGridUM.add(t14);
        textGridUM.add(t15);
        textGridUM.add(t23);
        textGridUM.add(t24);
        textGridUM.add(t25);
        UM.add(textGridUM);
        UM.setMargin(new Insets(1, 1, 1, 1));

        String i = " 3 ";
        JTextField t06 = new JTextField(i);
        JTextField t07 = new JTextField(i);
        JTextField t08 = new JTextField(i);
        JTextField t16 = new JTextField(i);
        JTextField t17 = new JTextField(i);
        JTextField t18 = new JTextField(i);
        JTextField t26 = new JTextField(i);
        JTextField t27 = new JTextField(i);
        JTextField t28 = new JTextField(i);

        JPanel textGridUR = new JPanel();
        textGridUR.setLayout(new GridLayout(3,3));
        textGridUR.add(t06);
        textGridUR.add(t07);
        textGridUR.add(t08);
        textGridUR.add(t16);
        textGridUR.add(t17);
        textGridUR.add(t18);
        textGridUR.add(t26);
        textGridUR.add(t27);
        textGridUR.add(t28);
        UR.add(textGridUR);
        UR.setMargin(new Insets(1, 1, 1, 1));


        String j = " 4 ";
        JTextField t30 = new JTextField(j);
        JTextField t31 = new JTextField(j);
        JTextField t32 = new JTextField(j);
        JTextField t40 = new JTextField(j);
        JTextField t41 = new JTextField(j);
        JTextField t42 = new JTextField(j);
        JTextField t50 = new JTextField(j);
        JTextField t51 = new JTextField(j);
        JTextField t52 = new JTextField(j);

        JPanel textGridML = new JPanel();
        textGridML.setLayout(new GridLayout(3,3));
        textGridML.add(t30);
        textGridML.add(t31);
        textGridML.add(t32);
        textGridML.add(t40);
        textGridML.add(t41);
        textGridML.add(t42);
        textGridML.add(t50);
        textGridML.add(t51);
        textGridML.add(t52);
        ML.add(textGridML);
        ML.setMargin(new Insets(1, 1, 1, 1));

        String k = " 5 ";
        JTextField t33 = new JTextField(k);
        JTextField t34 = new JTextField(k);
        JTextField t35 = new JTextField(k);
        JTextField t43 = new JTextField(k);
        JTextField t44 = new JTextField(k);
        JTextField t45 = new JTextField(k);
        JTextField t53 = new JTextField(k);
        JTextField t54 = new JTextField(k);
        JTextField t55 = new JTextField(k);

        JPanel textGridMM = new JPanel();
        textGridMM.setLayout(new GridLayout(3,3));
        textGridMM.add(t33);
        textGridMM.add(t34);
        textGridMM.add(t35);
        textGridMM.add(t43);
        textGridMM.add(t44);
        textGridMM.add(t45);
        textGridMM.add(t53);
        textGridMM.add(t54);
        textGridMM.add(t55);
        MM.add(textGridMM);
        MM.setMargin(new Insets(1, 1, 1, 1));

        String m = " 6 ";
        JTextField t36 = new JTextField(m);
        JTextField t37 = new JTextField(m);
        JTextField t38 = new JTextField(m);
        JTextField t46 = new JTextField(m);
        JTextField t47 = new JTextField(m);
        JTextField t48 = new JTextField(m);
        JTextField t56 = new JTextField(m);
        JTextField t57 = new JTextField(m);
        JTextField t58 = new JTextField(m);

        JPanel textGridMR = new JPanel();
        textGridMR.setLayout(new GridLayout(3,3));
        textGridMR.add(t36);
        textGridMR.add(t37);
        textGridMR.add(t38);
        textGridMR.add(t46);
        textGridMR.add(t47);
        textGridMR.add(t48);
        textGridMR.add(t56);
        textGridMR.add(t57);
        textGridMR.add(t58);
        MR.add(textGridMR);
        MR.setMargin(new Insets(1, 1, 1, 1));

        String n = " 7 ";
        JTextField t60 = new JTextField(n);
        JTextField t61 = new JTextField(n);
        JTextField t62 = new JTextField(n);
        JTextField t70 = new JTextField(n);
        JTextField t71 = new JTextField(n);
        JTextField t72 = new JTextField(n);
        JTextField t80 = new JTextField(n);
        JTextField t81 = new JTextField(n);
        JTextField t82 = new JTextField(n);

        JPanel textGridLL = new JPanel();
        textGridLL.setLayout(new GridLayout(3,3));
        textGridLL.add(t60);
        textGridLL.add(t61);
        textGridLL.add(t62);
        textGridLL.add(t70);
        textGridLL.add(t71);
        textGridLL.add(t72);
        textGridLL.add(t80);
        textGridLL.add(t81);
        textGridLL.add(t82);
        LL.add(textGridLL);
        LL.setMargin(new Insets(1, 1, 1, 1));

        String o = " 8 ";
        JTextField t63 = new JTextField(o);
        JTextField t64 = new JTextField(o);
        JTextField t65 = new JTextField(o);
        JTextField t73 = new JTextField(o);
        JTextField t74 = new JTextField(o);
        JTextField t75 = new JTextField(o);
        JTextField t83 = new JTextField(o);
        JTextField t84 = new JTextField(o);
        JTextField t85 = new JTextField(o);

        JPanel textGridLM = new JPanel();
        textGridLM.setLayout(new GridLayout(3,3));
        textGridLM.add(t63);
        textGridLM.add(t64);
        textGridLM.add(t65);
        textGridLM.add(t73);
        textGridLM.add(t74);
        textGridLM.add(t75);
        textGridLM.add(t83);
        textGridLM.add(t84);
        textGridLM.add(t85);
        LM.add(textGridLM);
        LM.setMargin(new Insets(1, 1, 1, 1));

        String p = " 9 ";
        JTextField t66 = new JTextField(p);
        JTextField t67 = new JTextField(p);
        JTextField t68 = new JTextField(p);
        JTextField t76 = new JTextField(p);
        JTextField t77 = new JTextField(p);
        JTextField t78 = new JTextField(p);
        JTextField t86 = new JTextField(p);
        JTextField t87 = new JTextField(p);
        JTextField t88 = new JTextField(p);

        JPanel textGridLR = new JPanel();
        textGridLR.setLayout(new GridLayout(3,3));
        textGridLR.add(t66);
        textGridLR.add(t67);
        textGridLR.add(t68);
        textGridLR.add(t76);
        textGridLR.add(t77);
        textGridLR.add(t78);
        textGridLR.add(t86);
        textGridLR.add(t87);
        textGridLR.add(t88);
        LR.add(textGridLR);
        LR.setMargin(new Insets(1, 1, 1, 1));

        JToggleButton jbtSudokuGenerator = new JToggleButton("generate");
        jbtSudokuGenerator.setPreferredSize(new Dimension(90, 45));
        jbtSudokuGenerator.setBackground(Color.GREEN);


        jbtSudokuGenerator.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                char[][] game;
                game = Generator.Sudoku();

                t00.setText(flipIt((int) game[0][0]));
                t01.setText(flipIt((int) game[0][1]));
                t02.setText(flipIt((int) game[0][2]));
                t03.setText(flipIt((int) game[0][3]));
                t04.setText(flipIt((int) game[0][4]));
                t05.setText(flipIt((int) game[0][5]));
                t06.setText(flipIt((int) game[0][6]));
                t07.setText(flipIt((int) game[0][7]));
                t08.setText(flipIt((int) game[0][8]));
                t10.setText(flipIt((int) game[1][0]));
                t11.setText(flipIt((int) game[1][1]));
                t12.setText(flipIt((int) game[1][2]));
                t13.setText(flipIt((int) game[1][3]));
                t14.setText(flipIt((int) game[1][4]));
                t15.setText(flipIt((int) game[1][5]));
                t16.setText(flipIt((int) game[1][6]));
                t17.setText(flipIt((int) game[1][7]));
                t18.setText(flipIt((int) game[1][8]));
                t20.setText(flipIt((int) game[2][0]));
                t21.setText(flipIt((int) game[2][1]));
                t22.setText(flipIt((int) game[2][2]));
                t23.setText(flipIt((int) game[2][3]));
                t24.setText(flipIt((int) game[2][4]));
                t25.setText(flipIt((int) game[2][5]));
                t26.setText(flipIt((int) game[2][6]));
                t27.setText(flipIt((int) game[2][7]));
                t28.setText(flipIt((int) game[2][8]));
                t30.setText(flipIt((int) game[3][0]));
                t31.setText(flipIt((int) game[3][1]));
                t32.setText(flipIt((int) game[3][2]));
                t33.setText(flipIt((int) game[3][3]));
                t34.setText(flipIt((int) game[3][4]));
                t35.setText(flipIt((int) game[3][5]));
                t36.setText(flipIt((int) game[3][6]));
                t37.setText(flipIt((int) game[3][7]));
                t38.setText(flipIt((int) game[3][8]));
                t40.setText(flipIt((int) game[4][0]));
                t41.setText(flipIt((int) game[4][1]));
                t42.setText(flipIt((int) game[4][2]));
                t43.setText(flipIt((int) game[4][3]));
                t44.setText(flipIt((int) game[4][4]));
                t45.setText(flipIt((int) game[4][5]));
                t46.setText(flipIt((int) game[4][6]));
                t47.setText(flipIt((int) game[4][7]));
                t48.setText(flipIt((int) game[4][8]));
                t50.setText(flipIt((int) game[5][0]));
                t51.setText(flipIt((int) game[5][1]));
                t52.setText(flipIt((int) game[5][2]));
                t53.setText(flipIt((int) game[5][3]));
                t54.setText(flipIt((int) game[5][4]));
                t55.setText(flipIt((int) game[5][5]));
                t56.setText(flipIt((int) game[5][6]));
                t57.setText(flipIt((int) game[5][7]));
                t58.setText(flipIt((int) game[5][8]));
                t60.setText(flipIt((int) game[6][0]));
                t61.setText(flipIt((int) game[6][1]));
                t62.setText(flipIt((int) game[6][2]));
                t63.setText(flipIt((int) game[6][3]));
                t64.setText(flipIt((int) game[6][4]));
                t65.setText(flipIt((int) game[6][5]));
                t66.setText(flipIt((int) game[6][6]));
                t67.setText(flipIt((int) game[6][7]));
                t68.setText(flipIt((int) game[6][8]));
                t70.setText(flipIt((int) game[7][0]));
                t71.setText(flipIt((int) game[7][1]));
                t72.setText(flipIt((int) game[7][2]));
                t73.setText(flipIt((int) game[7][3]));
                t74.setText(flipIt((int) game[7][4]));
                t75.setText(flipIt((int) game[7][5]));
                t76.setText(flipIt((int) game[7][6]));
                t77.setText(flipIt((int) game[7][7]));
                t78.setText(flipIt((int) game[7][8]));
                t80.setText(flipIt((int) game[8][0]));
                t81.setText(flipIt((int) game[8][1]));
                t82.setText(flipIt((int) game[8][2]));
                t83.setText(flipIt((int) game[8][3]));
                t84.setText(flipIt((int) game[8][4]));
                t85.setText(flipIt((int) game[8][5]));
                t86.setText(flipIt((int) game[8][6]));
                t87.setText(flipIt((int) game[8][7]));
                t88.setText(flipIt((int) game[8][8]));

            }});

        root.add(content);
        root.add(jbtSudokuGenerator);

        setContentPane(root);
        setTitle("Sudoku Grid");
        setVisible(true);}

    @SuppressWarnings("null")
    public char[][] dice81() {
        Random rand = new Random();
        char[][] diced81 = new char[9][9];
        diced81[0][0] = (char) rand.nextInt(10);
        diced81[0][1] = (char) rand.nextInt(10);
        diced81[0][2] = (char) rand.nextInt(10);
        diced81[0][3] = (char) rand.nextInt(10);
        diced81[0][4] = (char) rand.nextInt(10);
        diced81[0][5] = (char) rand.nextInt(10);
        diced81[0][6] = (char) rand.nextInt(10);
        diced81[0][7] = (char) rand.nextInt(10);
        diced81[0][8] = (char) rand.nextInt(10);
        diced81[1][0] = (char) rand.nextInt(10);
        diced81[1][1] = (char) rand.nextInt(10);
        diced81[1][2] = (char) rand.nextInt(10);
        diced81[1][3] = (char) rand.nextInt(10);
        diced81[1][4] = (char) rand.nextInt(10);
        diced81[1][5] = (char) rand.nextInt(10);
        diced81[1][6] = (char) rand.nextInt(10);
        diced81[1][7] = (char) rand.nextInt(10);
        diced81[1][8] = (char) rand.nextInt(10);
        diced81[2][0] = (char) rand.nextInt(10);
        diced81[2][1] = (char) rand.nextInt(10);
        diced81[2][2] = (char) rand.nextInt(10);
        diced81[2][3] = (char) rand.nextInt(10);
        diced81[2][4] = (char) rand.nextInt(10);
        diced81[2][5] = (char) rand.nextInt(10);
        diced81[2][6] = (char) rand.nextInt(10);
        diced81[2][7] = (char) rand.nextInt(10);
        diced81[2][8] = (char) rand.nextInt(10);
        diced81[3][0] = (char) rand.nextInt(10);
        diced81[3][1] = (char) rand.nextInt(10);
        diced81[3][2] = (char) rand.nextInt(10);
        diced81[3][3] = (char) rand.nextInt(10);
        diced81[3][4] = (char) rand.nextInt(10);
        diced81[3][5] = (char) rand.nextInt(10);
        diced81[3][6] = (char) rand.nextInt(10);
        diced81[3][7] = (char) rand.nextInt(10);
        diced81[3][8] = (char) rand.nextInt(10);
        diced81[4][0] = (char) rand.nextInt(10);
        diced81[4][1] = (char) rand.nextInt(10);
        diced81[4][2] = (char) rand.nextInt(10);
        diced81[4][3] = (char) rand.nextInt(10);
        diced81[4][4] = (char) rand.nextInt(10);
        diced81[4][5] = (char) rand.nextInt(10);
        diced81[4][6] = (char) rand.nextInt(10);
        diced81[4][7] = (char) rand.nextInt(10);
        diced81[4][8] = (char) rand.nextInt(10);
        diced81[5][0] = (char) rand.nextInt(10);
        diced81[5][1] = (char) rand.nextInt(10);
        diced81[5][2] = (char) rand.nextInt(10);
        diced81[5][3] = (char) rand.nextInt(10);
        diced81[5][4] = (char) rand.nextInt(10);
        diced81[5][5] = (char) rand.nextInt(10);
        diced81[5][6] = (char) rand.nextInt(10);
        diced81[5][7] = (char) rand.nextInt(10);
        diced81[5][8] = (char) rand.nextInt(10);
        diced81[6][0] = (char) rand.nextInt(10);
        diced81[6][1] = (char) rand.nextInt(10);
        diced81[6][2] = (char) rand.nextInt(10);
        diced81[6][3] = (char) rand.nextInt(10);
        diced81[6][4] = (char) rand.nextInt(10);
        diced81[6][5] = (char) rand.nextInt(10);
        diced81[6][6] = (char) rand.nextInt(10);
        diced81[6][7] = (char) rand.nextInt(10);
        diced81[6][8] = (char) rand.nextInt(10);
        diced81[7][0] = (char) rand.nextInt(10);
        diced81[7][1] = (char) rand.nextInt(10);
        diced81[7][2] = (char) rand.nextInt(10);
        diced81[7][3] = (char) rand.nextInt(10);
        diced81[7][4] = (char) rand.nextInt(10);
        diced81[7][5] = (char) rand.nextInt(10);
        diced81[7][6] = (char) rand.nextInt(10);
        diced81[7][7] = (char) rand.nextInt(10);
        diced81[7][8] = (char) rand.nextInt(10);
        diced81[8][0] = (char) rand.nextInt(10);
        diced81[8][1] = (char) rand.nextInt(10);
        diced81[8][2] = (char) rand.nextInt(10);
        diced81[8][3] = (char) rand.nextInt(10);
        diced81[8][4] = (char) rand.nextInt(10);
        diced81[8][5] = (char) rand.nextInt(10);
        diced81[8][6] = (char) rand.nextInt(10);
        diced81[8][7] = (char) rand.nextInt(10);
        diced81[8][8] = (char) rand.nextInt(10);
        return diced81;}

    public static String flipIt(int i){
        String str = null;
        char intChar = (char) i;
        //System.out.println(i+" "+ intChar);
        if (i == 46) str = ".";
        else if (i == 120) str = "x";
        else  str = ""+i;
        return str;
    }


    public static void main(String[] args) {

        SwingUtilities.invokeLater(Sudoku::new);// konstrukcja okna
        char[][] sudokuIreceived = Generator.Sudoku();

    }

}